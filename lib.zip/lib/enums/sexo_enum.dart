enum SexoEnum {
  masculino('Masculino'),
  feminino('Feminino');

  final String descricao;
  const SexoEnum(this.descricao);
}

// SexoEnum.MASCULINO
